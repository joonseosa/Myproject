package com.study.project;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ProjectController {

	@Resource(name = "service")
	private ProjectService projectService;
	
	
	@RequestMapping("login")
	public String login(){
				
		return "/login";
	}
	
	@RequestMapping("loginCheck")
	public String loginCheck(@RequestParam String memId,@RequestParam String memPw,Model model,HttpSession session) {
		Map<String, Object> memInfo =projectService.loginCheck(memId);
		
		
		if(memInfo == null || memInfo.isEmpty()) {
			// 아이디 입력 오류시
			model.addAttribute("loginChk", "errorId");
			return "/login";
		}else if(!memPw.equals(memInfo.get("memPass").toString())) {
			//비번 입력 오류시   비번이 같지 않다면 ! 
			model.addAttribute("loginChk", "errorPw");
			return "/login";
		}else {
			//로그인성공 , 세션 처리 
			session.setAttribute("memInfo", memInfo);
			return "redirect:list";
		}
		
		
		
	}
		
	@RequestMapping("logout")
	 public String logout(HttpSession session) {
		//세션 정보 날려버리기 
		session.invalidate();
		
		return "redirect:login";
	}
	 
	 
	 @RequestMapping("list")
	 public String list(@RequestParam Map<String, Object> map, Model model,HttpSession session) {
		 	

		 	Map<String, Object> memInfo = (Map<String, Object>)session.getAttribute("memInfo");
		 	String memId = memInfo.get("memId").toString();
		 	

		 	map.put("memId", memId);
		 	//mem rank 설정
		 	String memRank = memInfo.get("memRank").toString();
		 	
		 	
		 	
		 	//map에  memRank
		 	map.put("memRank", memRank);
		 	
		 	
		 List<Map<String, Object>> list = projectService.list(map); 
		 model.addAttribute("list",list);
		 
		 return "/list";
	 }
	 
	 @RequestMapping("write")
	 public String write(Model model) {
		  int seq = projectService.seq();
		 model.addAttribute("seq", seq);
		 model.addAttribute("ChkCond", "add");
		 return "/write";
	 }
	
	@RequestMapping("insert")
	public String insert(@RequestParam Map<String, Object> map) {
		 int insert = projectService.insert(map);	
		 int hisInsert = projectService.hisInsert(map);
		 
		return "redirect:list";
	}
	
	@RequestMapping("detail")
	public String detail(@RequestParam int seq,Model model,HttpSession session) {
			Map<String, Object> map = projectService.detail(seq);
			List<Map<String, Object>> hisList = projectService.hisList(seq);
			
			
			model.addAttribute("map",map);
			model.addAttribute("hisList", hisList);
			//detail에서  결재상태체크  
			model.addAttribute("ChkCond", "Chk");
		return "/detail";
	}
	
	@RequestMapping("detailUpdate")
	public String detailUpdate(@RequestParam Map<String, Object> map,@RequestParam int seq,Model model) {
		int update = projectService.detailUpdate(map);
		
		
		return "redirect:list";	
	}		
			
	@RequestMapping("detailInsert")
	public String detailInsert(@RequestParam Map<String, Object> map, HttpSession session ) {
		int seq = projectService.dataChk(map);
		
		Map<String, Object> memInfo = (Map<String, Object>)session.getAttribute("memInfo");
		
		map.put("memInfo", memInfo);
		String rank = memInfo.get("memRank").toString();
		String aChk = "Y";
		if((!"tmp".equals(map.get("appStatus").toString())) && ("ga".equals(rank) || "ba".equals(rank))){
			map.put("appChk", aChk);
		}
		
		if(seq == 0) {
			projectService.insert(map);
		}else {
			projectService.detailUpdate(map);
		}
			projectService.hisInsert(map);
		
		return "redirect:list";
	}
	
	
}
